create function st_inversetransformpipeline(geom geometry, pipeline text, to_srid integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT public.postgis_transform_pipeline_geometry($1, $2, FALSE, $3)$$;

alter function st_inversetransformpipeline(geometry, text, integer) owner to postgres;

