create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$SELECT '2025-05-17 23:37:54'::text AS version$$;

alter function postgis_scripts_build_date() owner to postgres;

